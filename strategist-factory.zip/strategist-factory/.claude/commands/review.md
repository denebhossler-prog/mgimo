Самопроверка перед воротами B: выполни skills/07_qa.md (субагенты red-team и fact-checker).
